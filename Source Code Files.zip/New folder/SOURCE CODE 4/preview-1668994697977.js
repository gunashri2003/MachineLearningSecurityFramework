;
import * as overview_0 from '/home/zoli/Library/Caches/Bit/capsules/05477724e6beef4627535027aa98d5f966dd9894/pnpm.network_ca-file@1.0.2/dist/ca-file.docs.mdx';

export const compositions = [];
export const overview = [overview_0];

export const compositions_metadata = {"compositions":[]};
